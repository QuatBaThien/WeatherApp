package com.example.weatherapp.data.WeatherCity

class WeatherList: ArrayList<DayWeatherCity>()