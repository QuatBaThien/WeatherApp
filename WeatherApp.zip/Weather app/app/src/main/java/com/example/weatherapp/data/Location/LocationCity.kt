package com.example.weatherapp.data.Location

class LocationCity : ArrayList<LocationCityItem>()