package com.example.weatherapp.data

import android.media.Image

data class DayWeather(
    var hour: String,
    var image:Int,
    var degree: String
)
